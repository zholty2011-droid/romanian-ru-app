rootProject.name = "RomanaRU"
include(":app")

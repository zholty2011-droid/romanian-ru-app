
Română RU — SOURCE for Codespaces

1) Open in GitHub Codespaces
2) Run:
   ./gradlew wrapper
   ./gradlew assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk
